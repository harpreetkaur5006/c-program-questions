#include<iostream>
using namespace std;
class multi{
    int a;
    int b;
    public:
    void setitem(){
        cin>>a>>b;
    }
    void getitem(){
        cout<<a*b;
    }
};
int main(){
    multi M;
    M.setitem();
    M.getitem();
}