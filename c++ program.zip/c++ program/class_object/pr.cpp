#include <iostream>
using namespace std;
class student
{
    int n;
    int id;
    int marks[100];
    float height;
    string name;

public:
    void set()
    {
        cout << "Enter student id" << endl;
        cin >> id;
        cout << "Enter student height: " << endl;
        cin >> height;
        cout << "Enter a name:" << endl;
        getline(cin, name);
        cout << "How many subject marks to enter: " << endl;
        cin >> n;
        for (int i = 0; i < n; i++)
        {
            cout<<"enter marks of:"<<i+1<<"subject";
            
            cin >> marks[i];
        }
    }
    void get()
    {
        cout << "id: " << id << " name is: " << name << " height is: " << height << " total marks: " << marks << endl;
    }
};
int main()
{
    cout << "how many students detail you want to enter";
    int k;
    cin >> k;
    student s[k];
    for (int i = 0; i < k; i++)
    {
        s[i].set();
        s[i].get();
    }
    return 0;
}