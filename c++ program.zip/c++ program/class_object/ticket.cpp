#include <iostream>
using namespace std;
class Ticket {
    string movie_name;
    int price;
public:
    void input() {
        getline(cin, movie_name);
        cin >> price;
    }

    void display() {
        cout << "Movie Name: " << movie_name << endl;
        cout << "Ticket Price: " << price << endl;
    }
};
int main() {
    Ticket t;
    t.input();
    t.display();
    return 0;
}