#include <iostream>
using namespace std;

class Product {
    int product_id;
    float price;

public:
    void input() {
        cin >> product_id >> price;
    }

    void display() {
        cout << "Product ID: " << product_id << ", Price: " << price << endl;
    }
};

int main() {
    Product products[4];

    // Input for 4 products
    for (int i = 0; i < 4; i++) {
        products[i].input();
    }

    // Display details
    for (int i = 0; i < 4; i++) {
        products[i].display();
    }

    return 0;
}