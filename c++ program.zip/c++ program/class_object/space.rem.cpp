#include<iostream>
using namespace std;

class spaceRemover{
    string str;
public:     
    void setData(){
        getline(cin, str);
    }

    void removespace(){
        string result = "";
        bool space = false;

        for (int i = 0; i < str.length(); i++)
        {
            if (str[i] != ' ')
            {
                result +=str[i];
                space = false;
            }

            else if (!space)
            {
                result += ' ';
                space = true;
            }
        }
        if (result[0] == ' ')
        {
            result.erase(0, 1);
        }

        if (result[result.length() - 1] == ' ')
        {
            result.erase(result.length()-1, 1);
        }
        
        str = result;
    }

    void display(){
        cout << str << endl;
    }
};

int main(){
    spaceRemover obj; 
    obj.setData();
    obj.removespace();
    obj.display();
    return 0;
}