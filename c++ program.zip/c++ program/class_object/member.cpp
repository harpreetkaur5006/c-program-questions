#include <iostream>
using namespace std;

class Member {
    string name;
    int duration;

public:
    void input() {
        getline(cin, name);   
        cin >> duration;      
    }

    void display() {
        cout << "Member Name: " << name << endl;
        cout << "Membership Duration: " << duration << " months" << endl;
    }
};

int main() {
    Member m;

    m.input();     
    m.display();   

    return 0;
}+
