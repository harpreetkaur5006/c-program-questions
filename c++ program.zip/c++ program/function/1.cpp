// //func with arg and without return value
//#include<iostream>
//using namespace std;
//void add(int a, int b);//declaring
//int main(){
//int x,y;
//cin>>x>>y;
//add(x,y);//calling
//return 0;
//}
//void add(intm,int n){//defining
//intz=m+n;
//cout<<z;
//}

//without arg and without return value
#include <iostream>
using namespace std;
void add(){
    int x,y;
    cin>>x>>y;
    int z=x+y;
    cout<<z;
}
int main(){
    add();
}