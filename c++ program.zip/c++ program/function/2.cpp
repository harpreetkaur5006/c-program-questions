// //func with arg with return value
// #include <iostream>
// using namespace std;
// void add();
// int main(){
//     add();
//     cout<<"finish";
//     return 0;
// }
// void add(){
//     int x,y,z;
//     cin>>x>>y;
//     z=x+y;
//     cout<<z;
// }

// func without arg with rv
#include <iostream>
using namespace std;
int add();
int main(){
    cout <<add();
    return 0;
}
    int add(){
        int x,y;
        cin>>x>>y;
        return x+y;
    }