#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    
    for(int i=1;i<n;i++){
        int temp=arr[i];
        int j=i-1;
        if(arr[i]%2==0){ 
        for(j;j>=0 && arr[j]%2!=0;j--){
            arr[j+1]=arr[j];
        }
        arr[j+1]=temp;
    }
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}