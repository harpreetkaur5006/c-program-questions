#include<iostream>
using namespace std;
class hp{
    public:
    int num;
    string name;
};
int main(){
    hp victus;
    victus.num=15;
    victus.name="some text";
    cout<<victus.num<<endl;
    cout<<victus.name;
}